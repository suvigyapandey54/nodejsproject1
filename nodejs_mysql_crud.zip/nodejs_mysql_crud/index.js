const studentForm = document.getElementById('student-form');
const studentDetailsDiv = document.getElementById('student-details');

studentForm.addEventListener('submit', (e) => {
e.preventDefault();
const name = document.getElementById('name').value;
const rollno = document.getElementById('rollno').value;

fetch('api/v1/student', {
method: 'GET',
headers: {
'Content-Type': 'application/json'
},
body: JSON.stringify({ name, rollno })
})
.then(response => response.json())
.then(data => {
const detailsHTML = `
<h2>Student Details</h2>
<p>Name: ${data.name}</p>
<p>Roll Number: ${data.rollno}</p>
<p>Class: ${data.class}</p>
<p>fees:${data.fees}</p>

`;
studentDetailsDiv.innerHTML = detailsHTML;
})
.catch(error => console.error(error));
});


app.post('/view', function(req,res){
    db.serialize(()=>{
      db.each('SELECT Name NAME,roll_no ROLLNO FROM students WHERE id =?', [req.body.id], function(err,row){     //db.each() is only one which is funtioning while reading data from the DB
        if(err){
          res.send("Error encountered while displaying");
          return console.error(err.message);
        }
        res.send(` Name : ${row.Name},    Roll_no: ${row.rollno}`);
        console.log("Entry displayed successfully");
      });
    });
  });
  