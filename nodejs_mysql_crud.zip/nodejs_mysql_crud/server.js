const express =require('express')
const colors =require('colors')
const morgan =require('morgan')
const dotenv =require('dotenv');
const mysqlPool = require('./config/db');

//dotenv configure

dotenv.config();

///rest object
const app =express()

//middle wares
app.use(express.json()  )
app.use(morgan("dev"));

//routes
app.use("/api/v1/student",require("./routes/studentRoutes"));  

app.get("/test",(req,res)=> {
    res.status(200).send("<h1> NODEJS MYSQL APP</h1>");
})

//port 
const PORT =process.env.PORT ||8000;

//conditionally listen

mysqlPool.query('SELECT 1').then(()=>{
  
    console.log("MY SQL DB CONNECTED".bgCyan.white )

})

//listen 
app.listen(PORT,() =>{
    console.log(`SERVER RUNNING ON PORT ${process.env.PORT}`.bgMagenta.white);
});